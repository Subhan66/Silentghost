﻿(function(a,b,c,d){
    a = 'https://tags.tiqcdn.com/utag/mtbank/olb-legacy/prod/utag.js';
    b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;
    a=b.getElementsByTagName(c)[0];a.parentNode.insertBefore(d,a);
})();
